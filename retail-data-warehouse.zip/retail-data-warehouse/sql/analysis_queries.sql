-- 1. Monthly Revenue per Region
SELECT 
    t.year,
    t.month,
    s.region,
    SUM(f.total_amount) AS total_revenue
FROM fact_sales f
JOIN time_dim t ON f.time_id = t.time_id
JOIN store_dim s ON f.store_id = s.store_id
GROUP BY t.year, t.month, s.region
ORDER BY t.year, t.month, s.region;

-- 2. Top 5 Products by Revenue in Each Region
WITH regional_sales AS (
    SELECT 
        p.product_name,
        s.region,
        SUM(f.total_amount) AS revenue,
        RANK() OVER (PARTITION BY s.region ORDER BY SUM(f.total_amount) DESC) AS rank
    FROM fact_sales f
    JOIN product_dim p ON f.product_id = p.product_id
    JOIN store_dim s ON f.store_id = s.store_id
    GROUP BY p.product_name, s.region
)
SELECT * FROM regional_sales
WHERE rank <= 5;

-- 3. Running Total of Sales per Store over Time
SELECT 
    s.store_name,
    t.date,
    SUM(f.total_amount) OVER (PARTITION BY f.store_id ORDER BY t.date) AS running_total
FROM fact_sales f
JOIN time_dim t ON f.time_id = t.time_id
JOIN store_dim s ON f.store_id = s.store_id
ORDER BY s.store_name, t.date;

-- 4. Year-over-Year Growth by Product Category
WITH yearly_revenue AS (
    SELECT 
        p.category,
        t.year,
        SUM(f.total_amount) AS revenue
    FROM fact_sales f
    JOIN time_dim t ON f.time_id = t.time_id
    JOIN product_dim p ON f.product_id = p.product_id
    GROUP BY p.category, t.year
),
growth_calc AS (
    SELECT 
        category,
        year,
        revenue,
        LAG(revenue) OVER (PARTITION BY category ORDER BY year) AS prev_year_revenue
    FROM yearly_revenue
)
SELECT 
    category,
    year,
    revenue,
    prev_year_revenue,
    ROUND(((revenue - prev_year_revenue) / prev_year_revenue) * 100, 2) AS yoy_growth_percent
FROM growth_calc
WHERE prev_year_revenue IS NOT NULL;
