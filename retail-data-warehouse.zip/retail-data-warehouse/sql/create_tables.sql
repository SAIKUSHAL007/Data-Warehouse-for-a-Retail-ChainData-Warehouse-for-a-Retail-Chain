-- Drop tables if they exist (for reruns)
DROP TABLE IF EXISTS fact_sales, product_dim, store_dim, time_dim;

-- Dimension: Product
CREATE TABLE product_dim (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(10, 2)
);

-- Dimension: Store
CREATE TABLE store_dim (
    store_id INT PRIMARY KEY,
    store_name VARCHAR(100),
    city VARCHAR(50),
    region VARCHAR(50)
);

-- Dimension: Time
CREATE TABLE time_dim (
    time_id INT PRIMARY KEY,
    date DATE,
    month VARCHAR(20),
    quarter VARCHAR(10),
    year INT
);

-- Fact Table: Sales
CREATE TABLE fact_sales (
    sale_id INT PRIMARY KEY,
    product_id INT REFERENCES product_dim(product_id),
    store_id INT REFERENCES store_dim(store_id),
    time_id INT REFERENCES time_dim(time_id),
    quantity_sold INT,
    total_amount DECIMAL(10, 2)
);
