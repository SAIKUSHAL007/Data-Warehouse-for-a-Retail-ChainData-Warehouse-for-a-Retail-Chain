-- Insert into product_dim
INSERT INTO product_dim VALUES
(1, 'Smartphone', 'Electronics', 500.00),
(2, 'Laptop', 'Electronics', 1200.00),
(3, 'Desk Chair', 'Furniture', 150.00),
(4, 'Notebook', 'Stationery', 5.00),
(5, 'Coffee Maker', 'Appliances', 80.00);

-- Insert into store_dim
INSERT INTO store_dim VALUES
(1, 'Store A', 'Hyderabad', 'South'),
(2, 'Store B', 'Mumbai', 'West'),
(3, 'Store C', 'Delhi', 'North'),
(4, 'Store D', 'Chennai', 'South');

-- Insert into time_dim
INSERT INTO time_dim VALUES
(1, '2024-01-15', 'January', 'Q1', 2024),
(2, '2024-02-20', 'February', 'Q1', 2024),
(3, '2024-03-18', 'March', 'Q1', 2024),
(4, '2025-01-10', 'January', 'Q1', 2025),
(5, '2025-02-12', 'February', 'Q1', 2025);

-- Insert into fact_sales
INSERT INTO fact_sales VALUES
(1, 1, 1, 1, 10, 5000.00),
(2, 2, 2, 2, 5, 6000.00),
(3, 3, 3, 3, 7, 1050.00),
(4, 4, 1, 4, 100, 500.00),
(5, 5, 4, 5, 20, 1600.00),
(6, 2, 3, 4, 3, 3600.00),
(7, 1, 2, 5, 15, 7500.00);
